<?php

class algoritmo {

    private $valor_maximo;
    private $valor_minimo;
    private $num_individuos;
    private $individuos = Array();
    private $IDpareja = Array();
    private $IDpareja_ = Array();
    private $array_x = Array();
    private $matriz_generacion = Array();
    private $matriz_mutacion = Array();
    private $mutacion;
    private $cruce;
    private $matriz_cruce = Array();
    private $fx;
    private $matriz_duplicado = Array();
    private $num_generaciones;

    function __autoload() {
        $this->num_individuos = 0;
        $this->valor_maximo = 0;
        $this->valor_minimo = 0;
    }

    function getFx() {
        return $this->fx;
    }

    function setFx($fx) {
        $this->fx = $fx;
    }

    function getNum_generaciones() {
        return $this->num_generaciones;
    }

    function setNum_generaciones($num_generaciones) {
        $this->num_generaciones = $num_generaciones;
    }

    function getValor_maximo() {
        return $this->valor_maximo;
    }

    function getValor_minimo() {
        return $this->valor_minimo;
    }

    function getNum_individuos() {
        return $this->num_individuos;
    }

    function setValor_maximo($valor_maximo) {
        $this->valor_maximo = $valor_maximo;
    }

    function setValor_minimo($valor_minimo) {
        $this->valor_minimo = $valor_minimo;
    }

    function setNum_individuos($num_individuos) {
        $this->num_individuos = $num_individuos;
    }

    function getIndividuos() {
        return $this->individuos;
    }

    function setIndividuos($individuos) {
        $this->individuos = $individuos;
    }

    function getIDpareja() {

        return $this->IDpareja;
    }

    function setIDpareja($IDpareja) {
        $this->IDpareja = $IDpareja;
    }
    function getIDpareja_old() {
        return $this->IDpareja_;
    }

    function setIDpareja_($IDpareja_) {
        $this->IDpareja_ = $IDpareja_;
    }

        function getMatriz_duplicado() {
        return $this->matriz_duplicado;
    }

    function setMatriz_duplicado($matriz_duplicado) {
        $this->matriz_duplicado = $matriz_duplicado;
    }

    function getMatriz_mutacion() {
        return $this->matriz_mutacion;
    }

    function getMatriz_cruce() {
        return $this->matriz_cruce;
    }

    function setMatriz_mutacion($matriz_mutacion) {
        $this->matriz_mutacion = $matriz_mutacion;
    }

    function setMatriz_cruce($matriz_cruce) {
        $this->matriz_cruce = $matriz_cruce;
    }

    function getMutacion() {
        return $this->mutacion;
    }

    function getCruce() {
        return $this->cruce;
    }

    function setMutacion($mutacion) {
        $this->mutacion = $mutacion;
    }

    function setCruce($cruce) {
        $this->cruce = $cruce;
    }

    function getMatriz_generacion() {
        return $this->matriz_generacion;
    }

    function setMatriz_generacion($matriz_generacion) {
        $this->matriz_generacion = $matriz_generacion;
    }

    function calculo() {
        $this->setIDpareja($this->emparejamiento());
        $x = 0;

        $binario = '';
        foreach ($this->getIndividuos() as $ind) {
            foreach ($ind as $i) {
                $binario.=$i;
            }
            $this->array_x[$x] = $this->binario($binario);
            $x++;
            $binario = '';
        }
        $this->generacionN();
        $this->generacionN_duplicado();
        $this->cruce();
        $this->mutacion();
    }

    function generacionN() {
        $m = new EvalMath;
        $m->suppress_errors = true;
        $matriz_pareja = Array();
        $matriz_generacion = Array();
        $parejas = Array();
        $parejas=$this->getIDpareja();
        $matriz_pareja[0] = $parejas[0][1];
        for ($i = 1; $i <= $this->getNum_individuos(); $i++) {
            $matriz_pareja[$i - 1] = $this->matriz_parejas($i,$parejas);
        }
        if ($m->evaluate('y(x) = ' . $this->getFx())) {
            for ($x = 0; $x < $this->getNum_individuos(); $x++) {
                $x = round($x, 2);
                $individuo = '';
                for ($i = 0; $i < $this->LongCromo(); $i++) {
                    $individuo.= $this->getIndividuos()[$x][$i];
                }
                $matriz_generacion[$x][0] = $x + 1;
                $matriz_generacion[$x][1] = $individuo;
                $matriz_generacion[$x][2] = $this->array_x[$x];
                $matriz_generacion[$x][3] = $m->e("y(" . $this->array_x[$x] . ")");
                $matriz_generacion[$x][4] = $matriz_pareja[$x];
            }
            $this->setMatriz_generacion($matriz_generacion);
            return $this->getMatriz_generacion();
        } else {
            return $m->last_error;
        }
    }

    function generacionN_duplicado() {
        $matriz_pareja = Array();
        $matriz_duplicado = Array();
        $individuo = Array();
        $aux_matrizGeneracion = $this->getMatriz_generacion();
        for ($i = 0; $i < $this->getNum_individuos(); $i++) {
            $val_1 = $aux_matrizGeneracion[$i][4];
            $val_2 = $aux_matrizGeneracion[$val_1 - 1][4];
            $ind_1 = $aux_matrizGeneracion[$val_1 - 1][1];
            $ind_2 = $aux_matrizGeneracion[$val_2 - 1][1];
            if ($aux_matrizGeneracion[$val_1 - 1][3] >= $aux_matrizGeneracion[$val_2 - 1][3]) {
                $individuo[$i] = $ind_1;
            } else {
                $individuo[$i] = $ind_2;
            }
        }
        //---------------------------------//
        $parejas = $this->emparejamiento();
        $this->setIDpareja_($parejas);
        $matriz_pareja[0] = $parejas[0][1];
        for ($i = 1; $i <= $this->getNum_individuos(); $i++) {
            $matriz_pareja[$i - 1] = $this->matriz_parejas($i,$parejas);
        }
        for ($x = 0; $x < $this->getNum_individuos(); $x++) {
            $x = round($x, 2);
            $matriz_duplicado[$x][0] = $x + 1;
            $matriz_duplicado[$x][1] = $individuo[$x];
            $matriz_duplicado[$x][2] = $matriz_pareja[$x];
        }
        $this->setMatriz_duplicado($matriz_duplicado);
        return $this->getMatriz_duplicado();
    }

    function cruce() {
        $matriz_pareja = Array();
        $cruce = Array();
        $parejas = $this->getIDpareja_old();
        $matriz_pareja[0] = $parejas[0][1];
        for ($i = 1; $i <= $this->getNum_individuos(); $i++) {
            $matriz_pareja[$i - 1] = $this->matriz_parejas($i,$parejas);
        }
        for ($x = 0; $x < $this->getNum_individuos(); $x++) {
            $cruce[$x][0] = $x + 1;
            $cruce[$x][1] = substr($this->getMatriz_duplicado()[$x][1], 0, $this->PorcentCruce()) . substr($this->getMatriz_duplicado()[$matriz_pareja[$x] - 1][1], $this->PorcentCruce(), $this->LongCromo());
        }
        $this->setMatriz_cruce($cruce);
        return $this->getMatriz_cruce();
    }

    function mutacion() {
        $matriz_pareja = Array();
        $mutacion = Array();
        $individuo_azar = $this->PorcentMutacion();
        echo $individuo_azar;
        $mutacion = $this->getMatriz_cruce();
        for ($x = 0; $x < $individuo_azar; $x++) {
            $ind = rand(0, $this->getNum_individuos() - 1);
            $bit = rand(0, $this->LongCromo() - 1);
            $valor =$mutacion[$ind][1];
            $valor[$bit] = $valor[$bit] == 1 ? '0' : '1';
            $mutacion[$ind][1] = $valor . '*';
        }
        $this->setMatriz_mutacion($mutacion);
        return $this->getMatriz_mutacion();
    }
    
function matriz_parejas($i,$matriz) {
        for ($j = 0; $j < $this->getNum_individuos() / 2; $j++) {
            if ($matriz[$j][0] == $i) {
                return $matriz[$j][1];
            } elseif ($matriz[$j][1] == $i) {
                return $matriz[$j][0];
            }
        }
    }

    function generarIndividuos() {
        $individuos = Array();
        for ($i = 0; $i < $this->getNum_individuos(); $i++) {
            for ($j = 0; $j < $this->LongCromo(); $j++) {
                $individuos[$i][$j] = rand(0, 1);
            }
        }
        $this->setIndividuos($individuos);
    }

    function nuevosIndividuos($inds) {
        $individuos = Array();
        for ($i = 0; $i < $this->getNum_individuos(); $i++) {
            for ($j = 0; $j < $this->LongCromo(); $j++) {
                $individuos[$i][$j] = intval($this->getMatriz_mutacion()[$i][1][$j]);
            }
        }
        $this->setIndividuos($individuos);
    }

    function emparejamiento() {
        $array = Array();
        $array[0][1] = rand(2, $this->num_individuos);
        $array[0][0] = 1;
        for ($i = 1; $i < $this->num_individuos / 2; $i++) {
            $id = rand(2, $this->num_individuos);
            $array[$i][1] = 0;
            $array[$i][0] = $i + 1;
            $array[$i][0] = $this->emparejar($i + 1, $array);
            $array[$i][1] = $this->emparejar($id, $array);
        }
        return $array;
    }

    function emparejar($id, $array) {
        if (!$this->existe_pareja($id, $array)) { // our base case
            return $id;
        } else {
            return $this->emparejar(rand(2, $this->num_individuos), $array); // <--calling itself.
        }
    }

    function existe_pareja($id, $array) {
        for ($i = 0; $i < count($array); $i++) {
            if ($array[$i][0] == $id || $array[$i][1] == $id) {
                return true;
            }
        }
        return false;
    }

    function binario($binario) {
        $decimal = 0;
        $base = 1;
        for ($i = strlen($binario) - 1; $i >= 0; $i--) {
            $decimal+=$binario[$i] * $base;
            $base*=2;
            //echo $decimal;
        }
        return $decimal;
    }

    public function LongCromo() {
        for ($i = 1; $i <= $this->getValor_maximo(); $i++) {
            if (pow(2, $i) <= $this->getValor_maximo()) {
                $long = $i;
            }
        }
        return $long + 1;
    }

    public function PorcentCruce() {
        $cruce = $this->LongCromo() * ($this->getCruce() / 100);
        return round($cruce);
    }

    public function PorcentMutacion() {
        $mutacion = $this->getNum_individuos() * ($this->getMutacion() / 100);
        return round($mutacion);
    }

}

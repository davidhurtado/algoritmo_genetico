<?php
//Evitar la inclusion directa de archivos -->
defined("SANDY") ? null : die("[Error]: No se puede acceder directamente a este archivo.");

//Control de errores -->
error_reporting(E_ALL);
ini_set("display_errors", 1 );

//Gestor de sesiones -->
session_start();

//Rutas y Directorios -->
defined("DS") ? null : define("DS", DIRECTORY_SEPARATOR);
defined("ROOT") ? null : define("ROOT", dirname(__FILE__).DS."..".DS );

// Crear objeto o clase vacia -->
$G = new StdClass();

// Incluir el archivo de funciones generales -->
require_once (ROOT.DS."app".DS."functions.php");

// Incluir el archivo de las clases generales -->
require_once (ROOT.DS."app".DS."models".DS."algoritmo.class.php");
include (ROOT.DS."app".DS."models".DS."evalmath.class.php");

$G->config["w_url"]='http://localhost/ag_sandy/';
$G->config["w_nombre"]='Algoritmo Genetico';
// Gestionar las Excepciones -->
set_error_handler("loadErrorHandler");

$G->controller = isset($_GET["controller"]) ? htmlentities(trim($_GET["controller"])) : "home";

loadController( $G->controller );
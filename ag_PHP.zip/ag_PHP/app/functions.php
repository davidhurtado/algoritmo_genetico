<?php
//Evitar la inclusion directa de archivos -->
defined("SANDY") ? null : die("[Error]: No se puede acceder directamente a este archivo.");


function loadErrorHandler( $error_n, $error_str, $error_file, $error_line ){

    echo "<strong>[Error-Excepci&oacute;n]</strong><br/>";
    echo "<strong>Archivo:</strong> ".$error_file;
    echo "<strong>L&iacute;nea:</strong> ".$error_line;

    throw new ErrorException($error_str, 0, $error_n, $error_file, $error_line );

}
function loadController($controller){
    global $G, $config;
    if($path=isController($controller)){
       require_once ($path);
    }else{
        die('No se puede cargar el controlador');
    }
}
function isController($controller){
    $path=ROOT.'app'.DS.'controllers'.DS.$controller.'.php';
    if(file_exists($path)){
        return $path;
    }else{
        return false;
    }
}
function loadView($page){
    global $G;

    $path=ROOT.'app'.DS.'views'.DS.$page;
    if(file_exists($path)){
        require_once($path);
    }else{
        echo 'No se puede cargar la vista: '. basename($page);
    }
}

function redirectTo( $location ){
    if( !headers_sent()){
        header("Location: ".$location);
    }
}
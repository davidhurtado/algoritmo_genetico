<?php
    loadView('home.phtml');

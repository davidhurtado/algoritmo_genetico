<?php

$G->error = "ok";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $num_individuos = !empty($_POST["individuos"]) ? trim($_POST["individuos"])%2==0?trim($_POST["individuos"]):($G->error .= "El numero de individuos debe ser par.<br/>") : ($G->error .= "Falta individuo.<br/>");
    $valor_minimo = !empty($_POST["minvalor"]) ? trim($_POST["minvalor"]) : ($_POST["minvalor"] == 0) ? trim($_POST["minvalor"]) : ($G->error .= "Falta el valor minimo.<br/>");
    $valor_maximo = !empty($_POST["maxvalor"]) ? trim($_POST["maxvalor"]) : ($G->error .= "Falta el valor maximo.<br/>");
    $funcion = !empty($_POST["fx"]) ? trim($_POST["fx"]) : ($G->error .= "Falta la funcion.<br/>");
    $cruce = !empty($_POST["cruce"]) ? trim($_POST["cruce"]) : ($G->error .= "Falta cruce.<br/>");
    $num_generaciones = !empty($_POST["generaciones"]) ? trim($_POST["generaciones"]) : ($G->error .= "Falta numero de generaciones.<br/>");
    $mutacion = !empty($_POST["mutacion"]) ? trim($_POST["mutacion"]) : ($G->error .= "Falta mutacion.<br/>");
    if ($G->error == "ok") {
        $G->algoritmo = new algoritmo();
        $G->algoritmo->setNum_individuos($num_individuos);
        $G->algoritmo->setNum_generaciones($num_generaciones);
        $G->algoritmo->setValor_maximo($valor_maximo);
        $G->algoritmo->setValor_minimo($valor_minimo);
        $G->algoritmo->setMutacion($mutacion);
        $G->algoritmo->setCruce($cruce);
        $G->algoritmo->setFx($funcion);
        $G->algoritmo->generarIndividuos();
        $G->algoritmo->calculo();
    }
}
loadView('algoritmo/algoritmo.phtml');

<?php

defined("SANDY") ? null : define("SANDY", true);
require_once ("./app/loader.php");
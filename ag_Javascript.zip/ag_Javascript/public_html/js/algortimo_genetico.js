var valor_maximo;
var valor_minimo;
var num_individuos;
var matriz_individuos = [];
var IDpareja = [];
var IDpareja_ = [];
var columna_x = [];
var matriz_generacion = [];
var matriz_mutacion = [];
var mutacion;
var cruce;
var matriz_cruce = [];
var fx;
var matriz_duplicado = [];
var num_generaciones;
function getFuncion() {
    return this.fx;
}

function setFuncion(fx) {
    this.fx = fx;
}

function getNum_generaciones() {
    return this.num_generaciones;
}

function setNum_generaciones(num_generaciones) {
    this.num_generaciones = num_generaciones;
}

function getValor_maximo() {
    return this.valor_maximo;
}

function getValor_minimo() {
    return this.valor_minimo;
}

function getNum_individuos() {
    return this.num_individuos;
}

function setValor_maximo(valor_maximo) {
    this.valor_maximo = valor_maximo;
}

function setValor_minimo(valor_minimo) {
    this.valor_minimo = valor_minimo;
}

function setNum_individuos(num_individuos) {
    this.num_individuos = num_individuos;
}

function getIndividuos() {
    return this.matriz_individuos;
}

function setIndividuos(matriz_individuos) {
    this.matriz_individuos = matriz_individuos;
}

function getIDpareja() {

    return this.IDpareja;
}

function setIDpareja(IDpareja) {
    this.IDpareja = IDpareja;
}
function getIDpareja_old() {
    return this.IDpareja_;
}

function setIDpareja_(IDpareja_) {
    this.IDpareja_ = IDpareja_;
}

function getMatriz_duplicado() {
    return this.matriz_duplicado;
}

function setMatriz_duplicado(matriz_duplicado) {
    this.matriz_duplicado = matriz_duplicado;
}

function getMatriz_mutacion() {
    return this.matriz_mutacion;
}

function getMatriz_cruce() {
    return this.matriz_cruce;
}

function setMatriz_mutacion(matriz_mutacion) {
    this.matriz_mutacion = matriz_mutacion;
}

function setMatriz_cruce(matriz_cruce) {
    this.matriz_cruce = matriz_cruce;
}

function getMutacion() {
    return this.mutacion;
}

function getCruce() {
    return this.cruce;
}

function setMutacion(mutacion) {
    this.mutacion = mutacion;
}

function setCruce(cruce) {
    this.cruce = cruce;
}

function getMatriz_generacion() {
    return this.matriz_generacion;
}

function setMatriz_generacion(matriz_generacion) {
    this.matriz_generacion = matriz_generacion;
}
function calculo() {
    this.setIDpareja(this.Emparejar());
    var binario = [];
    for (var i = 0; i < this.getNum_individuos(); i++) {
        for (var j = 0; j < this.Longitud_del_Cromo(); j++) {
            binario[j] = this.getIndividuos()[i][j];
        }
        this.columna_x[i] = binariyToInteger(binario);
    }
    this.generacion_Principal();
    this.Duplicado();
    this.Cruzar();
    this.Mutar();
}
function calculo_nuevo() {
    //this.matriz_individuos = [];
    this.IDpareja = [];
    this.IDpareja_ = [];
    this.columna_x = [];
    this.matriz_generacion = [];
    this.matriz_mutacion = [];
    this.matriz_cruce = [];
    this.matriz_duplicado = [];
    calculo();
}

function generacion_Principal() {
    m_pareja = [];
    m_generacion = [];
    pares = [];
    pares = this.getIDpareja();

    for (var i = 1; i <= this.getNum_individuos(); i++) {
        m_pareja[i - 1] = this.matriz_parejas(i, pares);
    }
    for (var x = 0; x < this.getNum_individuos(); x++) {
        var indiv = "";
        m_generacion[x] = [];
        for (var i = 0; i < this.Longitud_del_Cromo(); i++) {
            indiv += this.getIndividuos()[x][i];
        }
        letters.x = this.columna_x[x];
        m_generacion[x][0] = (x + 1);
        m_generacion[x][1] = indiv;
        m_generacion[x][2] = this.columna_x[x];
        m_generacion[x][3] = math.eval(this.getFuncion(), letters);
        m_generacion[x][4] = m_pareja[x];
    }
    this.setMatriz_generacion(m_generacion);
    return this.getMatriz_generacion();

}
function matriz_parejas(x, matriz) {
    for (var i = 0; i < this.getNum_individuos() / 2; i++) {
        if (matriz[i][0] == x) {
            return matriz[i][1];
        } else if (matriz[i][1] == x) {
            return matriz[i][0];
        }
    }
}

function Duplicado() {
    var m_pareja = [];
    var m_duplicado = [];
    var indiv = [];
    var aux_mGeneracion = this.getMatriz_generacion();
    for (var i = 0; i < this.getNum_individuos(); i++) {
        val1 = aux_mGeneracion[i][4];
        val2 = aux_mGeneracion[val1 - 1][4];
        ind1 = aux_mGeneracion[val1 - 1][1];
        ind2 = aux_mGeneracion[val2 - 1][1];
        if (aux_mGeneracion[val1 - 1][3] >= aux_mGeneracion[val2 - 1][3]) {
            indiv[i] = ind1;
        } else {
            indiv[i] = ind2;
        }
    }

    var pares = [];
    pares = this.Emparejar();
    this.setIDpareja_(pares);
    m_pareja[0] = pares[0][1];
    for (var i = 1; i <= this.getNum_individuos(); i++) {
        m_pareja[i - 1] = this.matriz_parejas(i, pares);
    }
    for (var x = 0; x < this.getNum_individuos(); x++) {
        m_duplicado[x] = [];
        m_duplicado[x][0] = x + 1;
        m_duplicado[x][1] = indiv[x];
        m_duplicado[x][2] = m_pareja[x];
    }
    this.setMatriz_duplicado(m_duplicado);
    return this.getMatriz_duplicado();
}

function Cruzar() {
    var m_pareja = [];
    var cruzar = [];
    var pares = this.getIDpareja_old();
    m_pareja[0] = pares[0][1];
    for (var i = 1; i <= this.getNum_individuos(); i++) {
        m_pareja[i - 1] = this.matriz_parejas(i, pares);
    }
    for (var j = 0; j < this.getNum_individuos(); j++) {
        cruzar[j] = [];
        cruzar[j][0] = j + 1;
        cruzar[j][1] = this.getMatriz_duplicado()[j][1].substr(0, this.CrucePorc()) + this.getMatriz_duplicado()[m_pareja[j] - 1][1].substr(this.CrucePorc(), this.Longitud_del_Cromo());
    }
    this.setMatriz_cruce(cruzar);
    return this.getMatriz_cruce();
}

function Mutar() {
    var m_pareja = [];
    var mutar = [];
    var indivAzar = this.MutacionPor();
    for (var i = 0; i < this.getNum_individuos(); i++) {
        mutar[i] = [];
        mutar[i][0] = i + 1;
        mutar[i][1] = this.getMatriz_cruce()[i][1];
    }
    for (var i = 0; i < indivAzar; i++) {
        var indi = getRandomArbitrary(0, this.getNum_individuos() - 1);
        var elemento = getRandomArbitrary(0, this.Longitud_del_Cromo() - 1);
        var val = '';
        for (var x = 0; x < mutar[indi][1].length; x++) {
            if (x == elemento) {
                if (mutar[indi][1][x] == 1) {
                    val += 0;
                } else {
                    val += 1;
                }
            } else {
                val += mutar[indi][1][x];
            }
        }
        mutar[indi][1] = val + '*';
    }
    this.setMatriz_mutacion(mutar);
    return this.getMatriz_mutacion();
}

function getRandomArbitrary(min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
function generarIndividuos() {
    m_individuos = [];
    for (var i = 0; i < this.getNum_individuos(); i++) {
        m_individuos[i] = [];
        for (var j = 0; j < this.Longitud_del_Cromo(); j++) {
            m_individuos[i][j] = Math.floor((Math.random() * 2));
        }
    }
    this.setIndividuos(m_individuos);
}


function nuevosIndividuos() {
    var individuos = [];
    for (var i = 0; i < this.getNum_individuos(); i++) {
        individuos[i] = [];
        for (var j = 0; j < this.Longitud_del_Cromo(); j++) {
            individuos[i][j] = parseInt(this.getMatriz_mutacion()[i][1][j]);
        }
    }
    this.setIndividuos(individuos);
}

function Emparejar() {
    var matriz = [];
    var num = [];
    for (var i = 0; i < this.num_individuos; i++) {
        num[i] = i+1;
    }
    var indice;
    var number;
    for (var i = 0; i < this.num_individuos / 2; i++) {
        indice = Math.floor(Math.random() * num.length);
        number = num[indice];
        matriz[i] = [];
        matriz[i][1] = number;
        num.splice(indice, 1);
        //->>
        indice = Math.floor(Math.random() * num.length);
        number = num[indice];
        matriz[i][0] = number;
        num.splice(indice, 1);

    }
    return matriz;
}


function Longitud_del_Cromo() {
    var longitud = 0;
    for (var i = 1; i <= this.getValor_maximo(); i++) {
        if (Math.pow(2, i) <= this.getValor_maximo()) {
            longitud = i;
        }
    }
    return longitud + 1;
}

function binariyToInteger(Bit_Vector) {
    var resultado = 0;

    var longi = Bit_Vector.length - 1;

    for (var i = 0; i < Bit_Vector.length; i++) {
        if (Bit_Vector[i] == 1) {
            resultado += Math.pow(2, longi - i);
        }
    }
    return resultado;
}

function CrucePorc() {
    cruzar = this.Longitud_del_Cromo() * (this.getCruce() / 100);
    return Math.round(cruzar);
}

function MutacionPor() {
    mutar = this.getNum_individuos() * (this.getMutacion() / 100);
    return Math.round(mutar);
}
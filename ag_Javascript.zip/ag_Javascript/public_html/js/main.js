// Creación del módulo
var angularRoutingApp = angular.module('angularRoutingApp', ['ngRoute']);
var funcion = '';
var individuos = '';
var generaciones = '';
var maximo = '';
var minimo = '';
var cruce = '';
var mutacion = '';
var tipo = 0;
var letters = {
    x: 3,
    e: 2.71,
    pi: 3.1415
};
// Configuración de las rutas
angularRoutingApp.config(function ($routeProvider) {

    $routeProvider
            .when('/', {
                templateUrl: 'pages/home.html',
                controller: 'mainController'
            })
            .when('/ingreso', {
                templateUrl: 'pages/ingreso.html',
                controller: 'ingresoController'
            })
            .when('/proceso', {
                templateUrl: 'pages/proceso.html',
                controller: 'procesoController'
            })
            .otherwise({
                redirectTo: '/'
            });
});


angularRoutingApp.controller('mainController', function ($scope) {
    $scope.message = 'Hola, Mundo!';
});

angularRoutingApp.controller('ingresoController', function ($scope) {
    $('#funcion').val(funcion);
    $('#individuos').val(individuos);
    $('#generaciones').val(generaciones);
    $('#maximo').val(maximo);
    $('#minimo').val(minimo);
    $('#cruce').val(cruce);
    $('#mutacion').val(mutacion);
    $('#tipo').val(tipo);
    if ($('#funcion').val() != '') {
        $('#frmreg').bootstrapValidator('validate');
    }
    $scope.message = 'Esta es la página ingreso';
});

angularRoutingApp.controller('procesoController', function ($scope) {
 //   var vueltas = [];
    var proceso = [];
    for (var x = 0; x < getNum_generaciones(); x++) {


        //Matriz generacion ->
        var generacion = {};
        generacion.list = getMatriz_generacion();

        //Matriz duplicidad ->
        var duplicidad = {};
        duplicidad.list = getMatriz_duplicado();

        //Matriz cruce ->
        var cruce = {};
        cruce.list = getMatriz_cruce();

        //Matriz mutacion ->
        var mutacion = {};
        mutacion.list = getMatriz_mutacion();

        proceso[x] = {generacion: generacion, duplicidad: duplicidad, cruce: cruce, mutacion: mutacion};
        // vueltas[x]= proceso;

        //nuevosIndividuos();
        var vueltas = {};
        vueltas.list = proceso;
        nuevosIndividuos();
        calculo();
        

    }
     $scope.mayor = getMayor();
      $scope.generacion_mayor = getnum_generacion_mayor();
    $scope.vueltas = vueltas;

});

$(document).ready(function () {
    var validator = $("#frmreg").bootstrapValidator({
        message: 'Este valor no es valido',
        feedbackIcons: {
            valid: 'glyphicon glyphicon-ok',
            invalid: 'glyphicon glyphicon-remove',
            validating: 'glyphicon glyphicon-refresh'
        },
        fields: {
            funcion: {
                message: "funcion requerida",
                validators: {
                    notEmpty: {
                        message: "Por favor ingrese la funcion"
                    }
                }
            },
            generaciones: {
                message: "Numero de generaciones requerido",
                validators: {
                    notEmpty: {
                        message: "Ingrese el numero de generaciones"
                    },
                    integer: {
                        message: "Ingrese un numero"
                    },
                }
            },
            individuos: {
                message: "Numero de individuos requerido",
                validators: {
                    notEmpty: {
                        message: "Ingrese el numero de individuos"
                    },
                    integer: {
                        message: "Ingrese un numero"
                    },
                }
            },
            maximo: {
                message: "Maximo requerido",
                validators: {
                    notEmpty: {
                        message: "Ingrese el valor maximo"
                    },
                    numeric: {
                        message: "Ingrese un numero"
                    },
                }
            },
            minimo: {
                message: "Minimo requerido",
                validators: {
                    notEmpty: {
                        message: "Ingrese el valor minimo"
                    },
                    numeric: {
                        message: "Ingrese un numero"
                    },
                }
            },
            cruce: {
                message: "Cruce requerido",
                validators: {
                    notEmpty: {
                        message: "Ingresar el cruce"
                    },
                    numeric: {
                        message: "Ingrese un numero"
                    },
                }
            },
            mutacion: {
                message: "Mutacion requerido",
                validators: {
                    notEmpty: {
                        message: "Ingresar el mutacion"
                    },
                    numeric: {
                        message: "Ingrese un numero"
                    },
                }
            },
            tipo: {
                // message: "Confirmar Password requerido",
                validators: {
                    greaterThan: {
                        value: 1,
                        message: "Seleccione un tipo"
                    }
                }
            }
        }
    });
    $('#calcular').click(function () {
        if ($('#frmreg').bootstrapValidator('validate').has('.has-error').length) {
        } else {
            funcion = $('#funcion').val();
            individuos = $('#individuos').val();
            generaciones = $('#generaciones').val();
            maximo = $('#maximo').val();
            minimo = $('#minimo').val();
            cruce = $('#cruce').val();
            mutacion = $('#mutacion').val();
            tipo = $('#tipo').val();
            setNum_individuos(individuos);
            setNum_generaciones(generaciones);
            setValor_maximo(maximo);
            setValor_minimo(minimo);
            setMutacion(mutacion);
            setCruce(cruce);
            setFuncion(funcion);
            generarIndividuos();
            calculo();
           
        }
    });

}
);
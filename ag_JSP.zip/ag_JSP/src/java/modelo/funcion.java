/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;
import org.lsmp.djep.djep.DJep;
import org.nfunk.jep.Node;
import org.nfunk.jep.ParseException;

/**
 *
 * @author David
 */
public class funcion {

    private DJep fxParse;
    private String funcion;

    public funcion() {
        {
            fxParse = new DJep();
            fxParse.addStandardConstants();
            //agrega constantes estandares, pi, e, etc
            fxParse.addStandardFunctions();
            //agrega funciones estandares cos(x), sin(x)
            fxParse.addComplex();
            //por si existe algun numero complejo
            fxParse.setAllowUndeclared(true);
            //permite variables no declarables
            fxParse.setAllowAssignment(true);
            //permite asignaciones
            fxParse.setImplicitMul(true);
            //regla de multiplicacion o para sustraccion y sumas
            fxParse.addStandardDiffRules();
        }
    }

    public funcion(String f) {
        fxParse = new DJep();
        this.funcion = f;
        fxParse.addStandardConstants();
        //agrega constantes estandares, pi, e, etc
        fxParse.addStandardFunctions();
        //agrega funciones estandares cos(x), sin(x)
        fxParse.addComplex();
        //por si existe algun numero complejo
        fxParse.setAllowUndeclared(true);
        //permite variables no declarables
        fxParse.setAllowAssignment(true);
        //permite asignaciones
        fxParse.setImplicitMul(true);
        //regla de multiplicacion o para sustraccion y sumas
        fxParse.addStandardDiffRules();
    }

    public String getFuncion() {
        return funcion;
    }

    public void setFuncion(String funcion) {
        this.funcion = funcion;
    }


    public Double EvaluarFuncion(double x) throws ParseException {
        Node re;
        String val;
        fxParse.addVariable("x", x);
        re = fxParse.parse(this.getFuncion());
        val = (fxParse.evaluate(re)).toString();
        return Double.parseDouble(val);

    }
}

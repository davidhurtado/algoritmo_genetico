/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

import static java.lang.Math.pow;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.lsmp.djep.djep.DJep;
import org.nfunk.jep.Node;
import org.nfunk.jep.ParseException;
import modelo.funcion;

/**
 *
 * @author estudiantes
 */
public class Algoritmo {

    private int individuosTotal;
    private int generacionesTotal;
    private int val_min;
    private int val_max;
    public int PorcentajeCruce;
    public int PorcentajeMutacion;
    private String funcion;
    public funcion fxParse = new funcion();
    Random genAlea = new Random();
    private int[][] matriz_pareja;
    private int[][] matriz_pareja_2;
    private int[] columna_x;
    private String[][] matriz_generacion;
    private String[][] matriz_mutacion;
    private String[][] matriz_cruce;
    private String[][] matriz_duplicado;
    private double[] max_valor;

    public int[][] individuos = new int[getIndividuosTotal()][Longitud_del_Cromo()];
//    public double[] valorIndividuos = new double[getIndividuosTotal()];
//    public double[][] tramosSeleccion = new double[getIndividuosTotal()][2];
//    public double[][] tramosCorte = new double[getCromosomasTotal()][2];
    int[] IDpareja = new int[getIndividuosTotal()];
//    int[] IDcruce = new int[getIndividuosTotal()];

    public Algoritmo() {
        this.funcion = "";
        this.individuosTotal = 0;
        this.val_min = 0;
        this.val_max = 0;
        this.PorcentajeCruce = 0;
        this.PorcentajeMutacion = 0;
        this.generacionesTotal = 0;
    }

    public void SizeMatrices() {
        this.fxParse.setFuncion(this.funcion);
        this.matriz_pareja = new int[this.getIndividuosTotal() / 2][2];
        this.matriz_pareja_2 = new int[this.getIndividuosTotal() / 2][2];
        this.columna_x = new int[this.getIndividuosTotal()];
        this.matriz_generacion = new String[this.getIndividuosTotal()][5];
        this.matriz_mutacion = new String[this.getIndividuosTotal()][3];
        this.matriz_cruce = new String[this.getIndividuosTotal()][3];
        this.matriz_duplicado = new String[this.getIndividuosTotal()][3];
        this.individuos = new int[this.getIndividuosTotal()][this.Longitud_del_Cromo()];
        this.max_valor = new double[this.getGeneracionesTotal()];
    }

    public String[][] getMatriz_duplicado() {
        return matriz_duplicado;
    }

    public void setMatriz_duplicado(String[][] matriz_duplicado) {
        this.matriz_duplicado = matriz_duplicado;
    }

    public int[] getIDpareja() {
        return IDpareja;
    }

    public void setIDpareja(int[] IDpareja) {
        this.IDpareja = IDpareja;
    }

    public int getIndividuosTotal() {
        return individuosTotal;
    }

    public void setIndividuosTotal(int individuosTotal) {
        this.individuosTotal = individuosTotal;
    }

    public int getGeneracionesTotal() {
        return generacionesTotal;
    }

    public void setGeneracionesTotal(int generacionesTotal) {
        this.generacionesTotal = generacionesTotal;
    }

    public int getVal_min() {
        return val_min;
    }

    public void setVal_min(int val_min) {
        this.val_min = val_min;
    }

    public int getVal_max() {
        return val_max;
    }

    public void setVal_max(int val_max) {
        this.val_max = val_max;
    }

    public int getPorcentajeCruce() {
        return PorcentajeCruce;
    }

    public void setPorcentajeCruce(int PorcentajeCruce) {
        this.PorcentajeCruce = PorcentajeCruce;
    }

    public int getPorcentajeMutacion() {
        return PorcentajeMutacion;
    }

    public void setPorcentajeMutacion(int PorcentajeMutacion) {
        this.PorcentajeMutacion = PorcentajeMutacion;
    }

    public String getFuncion() {
        return funcion;
    }

    public void setFuncion(String funcion) {
        this.funcion = funcion;
    }

    public int[][] getIndividuos() {
        return individuos;
    }

    public void setIndividuos(int[][] individuos) {
        this.individuos = individuos;
    }

    public int[][] getMatriz_pareja() {
        return matriz_pareja;
    }

    public void setMatriz_pareja(int[][] matriz_pareja) {
        this.matriz_pareja = matriz_pareja;
    }

    public int[] getColumna_x() {
        return columna_x;
    }

    public void setColumna_x(int[] columna_x) {
        this.columna_x = columna_x;
    }

    public String[][] getMatriz_generacion() {
        return matriz_generacion;
    }

    public void setMatriz_generacion(String[][] matriz_generacion) {
        this.matriz_generacion = matriz_generacion;
    }

    public int[][] getMatriz_pareja_2() {
        return matriz_pareja_2;
    }

    public void setMatriz_pareja_2(int[][] matriz_pareja_2) {
        this.matriz_pareja_2 = matriz_pareja_2;
    }

    public int[][] getMatriz_pareja_2_Antigua() {
        return matriz_pareja_2;
    }

    public int[] getIdParejaAntigua() {
        return IDpareja;
    }

    public String[][] getMatriz_cruce() {
        return matriz_cruce;
    }

    public void setMatriz_cruce(String[][] matriz_cruce) {
        this.matriz_cruce = matriz_cruce;
    }

    public String[][] getMatriz_mutacion() {
        return matriz_mutacion;
    }

    public void setMatriz_mutacion(String[][] matriz_mutacion) {
        this.matriz_mutacion = matriz_mutacion;
    }

    public double[] getMax_valor() {
        return max_valor;
    }

    public void setMax_valor(double[] max_valor) {
        this.max_valor = max_valor;
    }

    public void Calculo_del_Algoritmo() throws ParseException {

        this.setMatriz_pareja(this.emparejamiento());
        int x = 0;
        int[] binario = new int[this.Longitud_del_Cromo()];
        for (int i = 0; i < getIndividuosTotal(); i++) {
            for (int j = 0; j < this.Longitud_del_Cromo(); j++) {
                binario[j] = this.getIndividuos()[i][j];
            }

            this.columna_x[i] = binariyToInteger(binario);

        }

        this.generacion_Principal();
        //this.castigo_2();
        this.generacion_duplicada();
        this.cruce_individuos();
        //this.mutacion_individuos();
        this.Mutar();

//      
    }

    public void generarIndividuos() {
        int[] binario = new int[this.Longitud_del_Cromo()];
        int valor = 0;
        int[][] individuos = new int[this.getIndividuosTotal()][this.Longitud_del_Cromo()];
        for (int i = 0; i < this.getIndividuosTotal(); i++) {
            for (int j = 0; j < this.Longitud_del_Cromo(); j++) {
                individuos[i][j] = genAlea.nextInt(2);
            }
            for (int x = 0; x < this.Longitud_del_Cromo(); x++) {
                binario[x] = individuos[i][x];
            }
            valor = binariyToInteger(binario);
            if (valor >= this.getVal_max()) {
                i--;
            }
        }
        this.setIndividuos(individuos);
    }

    public String[][] generacion_Principal() throws ParseException {
        int[] matriz_pareja = new int[this.getIndividuosTotal()];
        String[][] matriz_generacion = new String[this.getIndividuosTotal()][5];
        int[][] parejas = new int[this.getIndividuosTotal() / 2][2];
        parejas = this.getMatriz_pareja();

        for (int i = 1; i <= this.getIndividuosTotal(); i++) {
            matriz_pareja[i - 1] = this.matriz_parejas(i, parejas);
        }
        for (int x = 0; x < this.getIndividuosTotal(); x++) {
            String individuo = "";
            for (int i = 0; i < this.Longitud_del_Cromo(); i++) {
                individuo += this.getIndividuos()[x][i];
            }

            matriz_generacion[x][0] = (x + 1) + "";
            matriz_generacion[x][1] = individuo;
            matriz_generacion[x][2] = this.columna_x[x] + "";
            matriz_generacion[x][3] = this.fxParse.EvaluarFuncion(this.columna_x[x]) + "";
            matriz_generacion[x][4] = matriz_pareja[x] + "";
        }
        this.setMatriz_generacion(matriz_generacion);
        return this.getMatriz_generacion();

    }

    public Double ValorMax() {
        String[][] matriz_generacion = new String[this.getIndividuosTotal()][5];
        matriz_generacion = this.getMatriz_generacion();
        double[] vector_max = new double[this.getGeneracionesTotal()];
        String num_max;
        double max = 0;
        for (int x = 0; x < this.getIndividuosTotal(); x++) {

            double pos1 = Double.parseDouble(matriz_generacion[x][3]);

            if (pos1 > max) {
                max = pos1;
            }

        }

        for (int i = 0; i < this.getGeneracionesTotal(); i++) {
            vector_max[i] = max;
        }

        this.setMax_valor(vector_max);

        return max;
    }

    public double valor_max_gen() {
        double[] vector_max = new double[this.getGeneracionesTotal()];
        vector_max = this.getMax_valor();
        double max = 0;
        for (int i = 0; i < this.getGeneracionesTotal(); i++) {
            if (vector_max[i] > max) {
                max = vector_max[i];
            }

            vector_max[i] = max;
        }

        return max;
    }

    public void nueva_poblacion() {
        int[][] individuos = new int[this.getIndividuosTotal()][this.Longitud_del_Cromo()];
        for (int i = 0; i < this.getIndividuosTotal(); i++) {
            for (int j = 0; j < this.Longitud_del_Cromo(); j++) {

                int com = (int) this.getMatriz_mutacion()[i][1].charAt(j);
                if (com == 48) {
                    individuos[i][j] = 0;
                } else {
                    individuos[i][j] = 1;
                }
            }
        }
        this.setIndividuos(individuos);
    }

    public String[][] cruce_individuos() {
        int[] matriz_pareja = new int[this.getIndividuosTotal()];
        String[][] matriz_cruce = new String[this.getIndividuosTotal()][3];
        int[][] parejas_individuos = new int[this.getIndividuosTotal() / 2][2];
        parejas_individuos = this.getMatriz_pareja_2_Antigua();
        matriz_pareja[0] = parejas_individuos[0][1];
        for (int i = 1; i <= this.getIndividuosTotal(); i++) {
            matriz_pareja[i - 1] = this.matriz_parejas(i, parejas_individuos);
        }
        for (int j = 0; j < this.getIndividuosTotal(); j++) {
            matriz_cruce[j][0] = (j + 1) + "";
            matriz_cruce[j][1] = this.getMatriz_duplicado()[j][1].substring(0, this.PorcentajeCruce()) + this.getMatriz_duplicado()[matriz_pareja[j] - 1][1].substring(this.PorcentajeCruce(), this.Longitud_del_Cromo());
        }
        this.setMatriz_cruce(matriz_cruce);
        return this.getMatriz_cruce();
    }

    public String[][] Mutar() {
        int[] matriz_pareja = new int[this.getIndividuosTotal()];
        String[][] aux_matriz_mutacion = new String[this.getIndividuosTotal()][3];
        int aleatorio_in = this.PorcentajeMutacion();

        for (int i = 0; i < this.getIndividuosTotal(); i++) {

            aux_matriz_mutacion[i][0] = (i + 1) + "";
            aux_matriz_mutacion[i][1] = this.getMatriz_cruce()[i][1];
        }
        String np = "";
        for (int j = 0; j < aleatorio_in; j++) {
            np = "";
            int bin = 0;

            int indi = (int) (Math.random() * (this.getIndividuosTotal() - 1));
            int cromosomas = (int) (Math.random() * (this.Longitud_del_Cromo() - 1));
            for (int i = 0; i < aux_matriz_mutacion[indi][1].length(); i++) {
                if (i == cromosomas) {
                    if (String.valueOf(aux_matriz_mutacion[indi][1].charAt(i)).equals("1")) {
                        np += "0";
                    } else {
                        np += "1";
                    }
                } else {
                    np += String.valueOf(aux_matriz_mutacion[indi][1].charAt(i));
                }
            }
            int[] ints = new int[np.length()];
            for (int y = 0; y < np.length(); y++) {
                ints[y] = Integer.parseInt(String.valueOf(np.charAt(y)));
            }

            bin = this.binariyToInteger(ints);
            if (bin > this.getVal_max()) {
                j--;
            } else {
                aux_matriz_mutacion[indi][1] = np ;
            }

        }

        this.setMatriz_mutacion(aux_matriz_mutacion);
        return this.getMatriz_mutacion();
    }

    public String[][] generacion_duplicada() {
        int[] matriz_pareja = new int[this.getIndividuosTotal()];
        String[][] matriz_duplicado = new String[this.getIndividuosTotal()][3];
        String[] individuo = new String[this.getIndividuosTotal()];
        String[][] aux_MGeneracion = new String[this.getIndividuosTotal()][5];
        aux_MGeneracion = this.getMatriz_generacion();
        for (int i = 0; i < this.getIndividuosTotal(); i++) {
            int val_1 = Integer.parseInt(aux_MGeneracion[i][4]);//3
            int val_2 = Integer.parseInt(aux_MGeneracion[val_1 - 1][4]);//1
            String id1 = aux_MGeneracion[val_1 - 1][1];//00110
            String id2 = aux_MGeneracion[val_2 - 1][1];//00010

            double pos1 = Double.parseDouble(aux_MGeneracion[val_1 - 1][3]);//36
            double pos2 = Double.parseDouble(aux_MGeneracion[val_2 - 1][3]);//4
            if (pos1 >= pos2) {
                individuo[i] = id1;
            } else {
                individuo[i] = id2;
            }
        }

        int[][] parejas = new int[this.getIndividuosTotal() / 2][2];
        parejas = this.emparejamiento();
        this.setMatriz_pareja_2(parejas);
        matriz_pareja[0] = parejas[0][1];
        for (int i = 1; i <= this.getIndividuosTotal(); i++) {
            matriz_pareja[i - 1] = this.matriz_parejas(i, parejas);
        }
        for (int j = 0; j < this.getIndividuosTotal(); j++) {

            matriz_duplicado[j][0] = (j + 1) + "";
            matriz_duplicado[j][1] = individuo[j];
            matriz_duplicado[j][2] = matriz_pareja[j] + "";
        }
        this.setMatriz_duplicado(matriz_duplicado);
        return this.getMatriz_duplicado();
    }

    public int matriz_parejas(int i, int[][] matriz) {
        for (int j = 0; j < this.getIndividuosTotal() / 2; j++) {
            if (matriz[j][0] == i) {
                return matriz[j][1];
            } else if (matriz[j][1] == i) {
                return matriz[j][0];
            }
        }
        return i;
    }

    public int[][] emparejamiento() {
        int[][] matriz = new int[this.getIndividuosTotal() / 2][2];
        matriz[0][1] = (int) (Math.random() * ((this.getIndividuosTotal()) - 1)) + 2;
        matriz[0][0] = 1;
        for (int i = 1; i < this.getIndividuosTotal() / 2; i++) {
            int id = (int) (Math.random() * ((this.getIndividuosTotal()) - 1)) + 2;
            matriz[i][1] = -1;
            matriz[i][0] = i + 1;
            matriz[i][0] = this.emparejar_individuos(i + 1, matriz);
            matriz[i][1] = this.emparejar_individuos(id, matriz);
        }
        return matriz;
    }

    public int emparejar_individuos(int num, int[][] array) {
        if (!this.pareja(num, array)) {
            return num;
        } else {
            return this.emparejar_individuos((int) (Math.random() * ((this.getIndividuosTotal()) - 1)) + 2, array);
        }
    }

    public boolean pareja(int id, int[][] array) {
        for (int i = 0; i < array.length; i++) {
            if (array[i][0] == id || array[i][1] == id) {
                return true;
            }
        }
        return false;
    }

    public int binariyToInteger(int[] Bit_Vector) {
        int resultado = 0;
        /* Resultado en entero */

        int lon = Bit_Vector.length - 1;

        for (int i = 0; i < Bit_Vector.length; i++) {
            if (Bit_Vector[i] == 1) {
                resultado += Math.pow(2, lon - i);
            }
        }
        return resultado;
    }

    public int Longitud_del_Cromo() {
        int longitud = 0;
        for (int i = 1; i <= this.getVal_max(); i++) {
            if (pow(2, i) <= this.getVal_max()) {
                longitud = i;
            }
        }
        return longitud + 1;
    }

    public int PorcentajeCruce() {
        int cruce = this.Longitud_del_Cromo() * this.getPorcentajeCruce() / 100;
        //* (this.getPorcentajeCruce() / 100)
        return cruce;
    }

    public int PorcentajeMutacion() {
        int mutacion = this.getIndividuosTotal() * this.getPorcentajeMutacion() / 100;
        return mutacion;
    }
}

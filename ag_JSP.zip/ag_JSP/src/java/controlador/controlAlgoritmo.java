/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlador;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import modelo.Algoritmo;
import modelo.funcion;
import org.nfunk.jep.ParseException;

/**
 *
 * @author David
 */
@WebServlet(name = "controlAlgoritmo", urlPatterns = {"/controlAlgoritmo.do"})
public class controlAlgoritmo extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
//            $num_individuos = !empty($_POST["individuos"]) ? trim($_POST["individuos"])%2==0?trim($_POST["individuos"]):($G->error .= "El numero de individuos debe ser par.<br/>") : ($G->error .= "Falta individuo.<br/>");
//    $valor_minimo = !empty($_POST["minvalor"]) ? trim($_POST["minvalor"]) : ($_POST["minvalor"] == 0) ? trim($_POST["minvalor"]) : ($G->error .= "Falta el valor minimo.<br/>");
//    $valor_maximo = !empty($_POST["maxvalor"]) ? trim($_POST["maxvalor"]) : ($_POST["maxvalor"] == 0) ? trim($_POST["maxvalor"]) : ($G->error .= "Falta el valor maximo.<br/>");
//    $funcion = !empty($_POST["fx"]) ? trim($_POST["fx"]) : ($G->error .= "Falta la funcion.<br/>");
//    $cruce = !empty($_POST["cruce"]) ? trim($_POST["cruce"]) : ($G->error .= "Falta cruce.<br/>");
//    $num_generaciones = !empty($_POST["generaciones"]) ? trim($_POST["generaciones"]) : ($G->error .= "Falta numero de generaciones.<br/>");
//    $mutacion = !empty($_POST["mutacion"]) ? trim($_POST["mutacion"]) : ($G->error .= "Falta mutacion.<br/>");
//    if ($G->error == "ok") {
//        $G->algoritmo = new algoritmo();
//        $G->algoritmo->setNum_individuos($num_individuos);
//        $G->algoritmo->setNum_generaciones($num_generaciones);
//        $G->algoritmo->setValor_maximo($valor_maximo);
//        $G->algoritmo->setValor_minimo($valor_minimo);
//        $G->algoritmo->setMutacion($mutacion);
//        $G->algoritmo->setCruce($cruce);
//        $G->algoritmo->setFx($funcion);
//        $G->algoritmo->generarIndividuos();
//        $G->algoritmo->calculo();
//    }
        ArrayList errores = new ArrayList();
        ArrayList datos = new ArrayList();
        String strindividuos = request.getParameter("txtindividuos");
        String strval_min = request.getParameter("txtval_min");
        String strval_max = request.getParameter("txtval_max");
        String strfuncion = request.getParameter("txtfuncion");
        String strcruce = request.getParameter("txtcruce");
        String strgeneraciones = request.getParameter("txtgeneraciones");
        String strmutacion = request.getParameter("txtmutacion");
        String url = "";
        int individuos = 0;
        int val_min = 0;
        int val_max = 0;
        double fx = 0;
        int cruce = 0;
        int generaciones = 0;
        int mutacion = 0;
        if (strfuncion.isEmpty()) {
            errores.add("Debe ingresar la funcion");
        } else {
            funcion func = new funcion(strfuncion);
            try {
                fx = func.EvaluarFuncion(1);
            } catch (NumberFormatException ex) {
                errores.add("Debe ingresar la funcion correcta ");
            }
        }
        try {
            individuos = Integer.parseInt(strindividuos);
            if(individuos %2!=0){
                errores.add("Debe ingresar numero de individuos pares");
            }
        } catch (NumberFormatException ex) {
            errores.add("Debe ingresar individuos");
        }
        try {
            val_min = Integer.parseInt(strval_min);
        } catch (NumberFormatException ex) {
            errores.add("Debe ingresar el valor minimo");
        }
        try {
            val_max = Integer.parseInt(strval_max);
        } catch (NumberFormatException ex) {
            errores.add("Debe ingresar el valor maximo");
        }

        try {
            cruce = Integer.parseInt(strcruce);
        } catch (NumberFormatException ex) {
            errores.add("Debe ingresar el cruce");
        }
        try {
            generaciones = Integer.parseInt(strgeneraciones);
            
        } catch (NumberFormatException ex) {
            errores.add("Debe ingresar las generaciones");
        }
        try {
            mutacion = Integer.parseInt(strmutacion);
        } catch (NumberFormatException ex) {
            errores.add("Debe ingresar la mutacion");
        }
        if (errores.isEmpty()) {
            Algoritmo ag;
            ag = new Algoritmo();
            url = "ag.jsp";
                        // $G->algoritmo->setNum_individuos($num_individuos);
//        $G->algoritmo->setNum_generaciones($num_generaciones);
//        $G->algoritmo->setValor_maximo($valor_maximo);
//        $G->algoritmo->setValor_minimo($valor_minimo);
//        $G->algoritmo->setMutacion($mutacion);
//        $G->algoritmo->setCruce($cruce);
//        $G->algoritmo->setFx($funcion);
            ag.setIndividuosTotal(individuos);
            ag.setGeneracionesTotal(generaciones);
            ag.setVal_max(val_max);
            ag.setVal_min(val_min);
            ag.setPorcentajeMutacion(mutacion);
            ag.setPorcentajeCruce(cruce);
            ag.setFuncion(strfuncion);
            ag.SizeMatrices();
            ag.generarIndividuos();
            ag.Calculo_del_Algoritmo();
            request.setAttribute("ag",ag);
        } else {
            url = "error.jsp";
            //guardar el mensaje en el ambito de la solicitud
            request.setAttribute("errores", errores);
            
        }
        RequestDispatcher vista = request.getRequestDispatcher(url);
        vista.include(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(controlAlgoritmo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(controlAlgoritmo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
